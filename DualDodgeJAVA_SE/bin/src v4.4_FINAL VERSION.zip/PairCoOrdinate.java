//has obstacle info. class could be named Obstacle
public class PairCoOrdinate { 
	    public int x, y, height, width;
	    PairCoOrdinate() {
	    }
	    PairCoOrdinate(int p1, int p2, int w, int h) {
	        this.x = p1;
	        this.y = p2;
	        this.height = h;
	        this.width =w;
	    }
}
